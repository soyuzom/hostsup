// ==UserScript==
// @name         购物党比价工具【精简版】
// @namespace    none
// @version      1.7.1
// @description  gwdang精简版 ，精简gwdang，减少弹窗，仅留下顶栏，并去除菜单部分
// @author       淘宝老司机
// @require      https://cdn.bootcss.com/jquery/2.2.4/jquery.min.js
// @include      http*://item.taobao.com/*
// @include      http*://detail.tmall.com/item.htm*
// @include      http*://chaoshi.detail.tmall.com/item.htm*
// @include      http*://item.jd.com/*
// @grant        GM_xmlhttpRequest
// @connect      chenzelin.herokuapp.com
// ==/UserScript==

host = 'chenzelin.herokuapp.com';

function tb_618(){
    var t;
    var a;
    t = document.querySelector('#J_Title');
    a = document.createElement('a');
    a.href = 'https://s.click.taobao.com/WKOV9Qw';
    a.innerText = '618狂欢节';
    a.style='padding: 2px; text-align: center;margin-bottom: 0;font-size: 14px;font-weight: normal;height:13px;lwhite-space: nowrap;vertical-align: middle;-ms-touch-action: manipulation;touch-action: manipulation;cursor: pointer;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;background-image: none;border: 1px solid transparent;border-radius:2px;color: #fff;background-color: #DF231C;#FF0036;margin-left:10px';
   t.insertBefore(a, t.children[-1])
}
function tm_618(){
    var t;
    var a;
    t = document.querySelector('#J_DetailMeta > div.tm-clear > div.tb-property > div > div.tb-detail-hd');
    a = document.createElement('a');
    a.href = 'https://s.click.taobao.com/WKOV9Qw';
    a.innerText = '618狂欢节';
    a.style='padding: 2px;ine-height:14px;text-align: center;margin-bottom: 0;font-size: 14px;font-weight: normal;height:14px;lwhite-space: nowrap;vertical-align: middle;-ms-touch-action: manipulation;touch-action: manipulation;cursor: pointer;-webkit-user-select: none;-moz-user-select: none;-ms-user-select: none;user-select: none;background-image: none;border: 1px solid transparent;border-radius:2px;color: #fff;background-color: #DF231C;#FF0036;margin-left:10px';
   t.insertBefore(a, t.children[-1])
}

function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]); return null;
}

function AutoStart(time, cssSelector, dealFunc) {
    var timerNode = setInterval(function () {
        try{
            if (document.querySelector(cssSelector) != null){
                clearInterval(timerNode);
                dealFunc();
            }
        }catch (e){}
    }, time);
}

function JudgeDelay(time, judgeFunc, dealFunc) {
    var timerNode = setInterval(function () {
        try{
            if (judgeFunc){
                clearInterval(timerNode);
                dealFunc();
            }
        }catch (e){}
    }, time);
}

function n_tm_card(_id, title, price, pic_url, coupon_info){
    var li = document.createElement('li');
    var div = document.createElement('div');
    li.appendChild(div);
    div.className = 'img';
    div.style="width: 70%; margin: 5px; border-bottom: black";
    var a = document.createElement('a');
    a.href="javaScript:void(0)";
    a.onclick = function(){n_item_click(_id);};
    div.appendChild(a);

    var img = document.createElement('img');
    a.appendChild(img);
    img.style="width: 100%;height: 100%; padding: 5px;";
    img.title=title;
    img.alt=title;
    img.src=pic_url;

    var b = document.createElement('a');
    b.onclick = function(){n_item_click(_id);};
    div.appendChild(b);
    b.style="padding: 5px; width: 100%; font-weight: bold; color: blue; display: flex; justify-content: center";
    b.innerText = price;
    if(coupon_info != 'NULL'){
        b.innerText +='|' + coupon_info;
    }
    return li;
}

function n_item_click(_id){
    GM_xmlhttpRequest({
        method: "GET", responseType: 'jsonp',
        url: "http://" + host + "/api/tb/id?id=" + _id,
        onload: function(resp) {
            try{
                var tks = $.parseJSON(resp.responseText);
                var item_url = tks[0];
                var item_coupon = tks[1];
                if (item_coupon.indexOf('taobao.com') > 0){
                    var a = document.createElement('a');
                    a.href=item_coupon;
                    a.click();
                } else if (item_url.indexOf('taobao.com') > 0){
                    var a = document.createElement('a');
                    a.href=item_url;
                    a.click();
                } else if (item_url == 'None') {
                    window.location = "https://item.taobao.com/item.htm?id=" + _id;
                }
            }catch(e) {
            }
        }
    });
}

function n_tm_init(){
    var get_name = '/static';
    var get_ext = '/gwdv1.js';
    var get_host = 'https://' + host;
    var s = document.createElement('script');
    s.setAttribute('charset', 'UTF-8');
    s.setAttribute('src', get_host + get_name + get_ext);
    document.body.appendChild(s);
}

function n_tm_init_sc(){
    var tp = document.querySelector('#gwdang-main > div.logo');
    tp.style.display ='none';
    tp = document.querySelector('#gwdang-feed-close');
    tp.style.display ='none';
    tp = document.querySelector('#gwdang-history');
    tp.style.display ='none';
}

function n_item_load_sc(item){
    try{
        var _id = item.dataset['id'];
        var chs = item.children;
        for(j=0;j<chs.length;j++){
            var a = chs[j];
            if(a.tagName == 'A'){
                a.onclick = function(){n_item_click(_id);};
                a.href = 'javaScript:void(0)';
            }
        }
    }catch(e){
    }
}

function Sleep (time) {
  return new Promise((resolve) => setTimeout(resolve, time));
}

function gwd_load_sc(){
    var nav = document.querySelector('#gwdang-main');
    AutoStart(2000, "#tmall-item-list", function(){
        var items = nav.querySelector('#tmall-item-list').children;
        for(i=0;i<items.length;i++){
            item = items[i];
            n_item_load_sc(item);
        }
    });
    AutoStart(2000, '#taobao-item-list', function(){
        var items = nav.querySelector('#taobao-item-list').children;
        for(i=0;i<items.length;i++){
            item = items[i];
            n_item_load_sc(item);
        }
    });
}

function n_tm_load(){
    nav = document.querySelector('#gwdang-main');
    var hid_span = document.querySelector('#ald-skuRight > div > div.ald-hd > span');
    hid_span.innerText = "";
    var hack = document.querySelector("#ald-skuRight");
    var dv = document.createElement('ul');
    hack.insertBefore(dv, hack.children[0]);
    var i;
    AutoStart(1000, "#tmall-item-list", function () {
        var items = nav.querySelector('#tmall-item-list').children;
        for(i=0;i<Math.min(2, items.length);i++){
            var item = items[i];
            var _id = item.dataset['id'];
            var img_a = item.children[0];
            var item_title = img_a.title;
            var pic_url = img_a.children[0].src;
            if (pic_url.indexOf('img.alicdn.com') < 0){
                Sleep(3000).then(function(){
                    var pic_url = img_a.children[0].src;
                    var coupon_info = 'NULL';
                    var price = 'NULL';
                    try{
                        coupon_info = img_a.querySelector('span.coupon_span').innerText;
                        price = item.children[1].children[2].innerText;
                    }catch(e){
                        price = item.querySelector('a.b2c-price-a').innerText;
                    }
                    var i_node = n_tm_card(_id, item_title, price, pic_url, coupon_info);
                    dv.appendChild(i_node);
                });
            } else {
                var coupon_info = 'NULL';
                var price = 'NULL';
                try{
                    coupon_info = img_a.querySelector('span.coupon_span').innerText;
                    price = item.children[1].children[2].innerText;
                }catch(e){
                    price = item.querySelector('a.b2c-price-a').innerText;
                }
                var i_node = n_tm_card(_id, item_title, price, pic_url, coupon_info);
                dv.appendChild(i_node);
            }
        }
    });
    AutoStart(1000, "#taobao-item-list", function () {
        var items = nav.querySelector('#taobao-item-list').children;
        for(i=0;i<Math.min(2, items.length);i++){
            var item = items[i];
            var _id = item.dataset['id'];
            var img_a = item.children[0];
            var item_title = img_a.title;
            var pic_url = img_a.children[0].src;
            if (pic_url.indexOf('img.alicdn.com') < 0){
                Sleep(3000).then(function(){
                    var pic_url = img_a.children[0].src;
                    var coupon_info = 'NULL';
                    var price = 'NULL';
                    try{
                        coupon_info = img_a.querySelector('span.coupon_span').innerText;
                        price = item.children[1].children[2].innerText;
                    }catch(e){
                        price = item.querySelector('a.b2c-price-a').innerText;
                    }
                    var i_node = n_tm_card(_id, item_title, price, pic_url, coupon_info);
                    dv.appendChild(i_node);
                });
            } else {
                var coupon_info = 'NULL';
                var price = 'NULL';
                try{
                    coupon_info = img_a.querySelector('span.coupon_span').innerText;
                    price = item.children[1].children[2].innerText;
                }catch(e){
                    price = item.querySelector('a.b2c-price-a').innerText;
                }
                var i_node = n_tm_card(_id, item_title, price, pic_url, coupon_info);
                dv.appendChild(i_node);
            }
        }
    });
}

function n_tb_card(_id, item_title, price, pic_url, coupon_info){
    var li = document.createElement('li');
    li.className = 'tuijian-item';
    var dv = document.createElement('div');
    dv.className = 'tuijian-l';
    li.appendChild(dv);

    var img_dv = document.createElement('div');
    img_dv.className = 'tuijian-img clearfix';
    dv.appendChild(img_dv);

    var pic_con_dv = document.createElement('div');
    pic_con_dv.className = 'pic-con';
    img_dv.appendChild(pic_con_dv);
    var img_a = document.createElement('a');
    img_a.href = "javaScript:void(0)";
    img_a.className = 'img-con';
    img_a.title = item_title;
    img_a.onclick = function(){n_item_click(_id);};
    pic_con_dv.appendChild(img_a);
    var img = document.createElement('img');
    img.src = pic_url;
    img.title = item_title;
    img.style.width = '100%';
    img.alt = item_title;
    img_a.appendChild(img);

    var price_p = document.createElement('p');
    price_p.className = 'tuijian-price';
    var price_sp = document.createElement('span');
    var b = document.createElement('b');
    b.innerText = price;
    price_sp.appendChild(b);
    price_p.appendChild(price_sp);
    li.appendChild(price_p);
    return li;
}

function n_tb_load(){
    nav = document.querySelector('#gwdang-main');
    var hack_u;
    try{
        hack_u = document.querySelector('#J_Pine > div > div.tuijian-bd.tb-clearfix > ul');
    }catch(e){
    }
    var i;
    AutoStart(4000, "#tmall-item-list", function () {
        var items = nav.querySelector('#tmall-item-list').children;
        try{
            for(i=0;i<Math.min(2, items.length);i++){
                var item = items[i];
                var _id = item.dataset['id'];
                var img_a = item.children[0];
                var item_title = img_a.title;
                var pic_url = img_a.children[0].src;
                if (pic_url.indexOf('img.alicdn.com') < 0){
                    Sleep(3000).then(function(){
                    var pic_url = img_a.children[0].src;
                    var coupon_info = 'NULL';
                    var price = 'NULL';
                    try{
                        coupon_info = img_a.querySelector('span.coupon_span').innerText;
                        price = item.children[1].children[2].innerText;
                    }catch(e){
                        price = item.querySelector('a.b2c-price-a').innerText;
                    }
                    var cd = n_tb_card(_id, item_title, price, pic_url, coupon_info);
                    hack_u.insertBefore(cd, hack_u.children[0]);
                    });
                } else {
                    var coupon_info = 'NULL';
                    var price = 'NULL';
                    try{
                        coupon_info = img_a.querySelector('span.coupon_span').innerText;
                        price = item.children[1].children[2].innerText;
                    }catch(e){
                        price = item.querySelector('a.b2c-price-a').innerText;
                    }
                    var cd = n_tb_card(_id, item_title, price, pic_url, coupon_info);
                    hack_u.insertBefore(cd, hack_u.children[0]);
                }
            }
        }catch(e){ }
    });
    AutoStart(4000, "#taobao-item-list", function () {
        var items = nav.querySelector('#taobao-item-list').children;
        try{
            for(i=0;i<Math.min(2, items.length);i++){
                var item = items[i];
                var _id = item.dataset['id'];
                var img_a = item.children[0];
                var item_title = img_a.title;
                var pic_url = img_a.children[0].src;
                if (pic_url.indexOf('img.alicdn.com') < 0){
                    Sleep(3000).then(function(){
                    var pic_url = img_a.children[0].src;
                    var coupon_info = 'NULL';
                    var price = 'NULL';
                    try{
                        coupon_info = img_a.querySelector('span.coupon_span').innerText;
                        price = item.children[1].children[2].innerText;
                    }catch(e){
                        price = item.querySelector('a.b2c-price-a').innerText;
                    }
                    var cd = n_tb_card(_id, item_title, price, pic_url, coupon_info);
                    hack_u.insertBefore(cd, hack_u.children[0]);
                    });
                } else {
                    var coupon_info = 'NULL';
                    var price = 'NULL';
                    try{
                        coupon_info = img_a.querySelector('span.coupon_span').innerText;
                        price = item.children[1].children[2].innerText;
                    }catch(e){
                        price = item.querySelector('a.b2c-price-a').innerText;
                    }
                    var cd = n_tb_card(_id, item_title, price, pic_url, coupon_info);
                    hack_u.insertBefore(cd, hack_u.children[0]);
                }
            }
        }catch(e){}
    });
}

n_tm_init();
AutoStart(100, "#gwdang-main", function () {
  n_tm_init_sc();
});
AutoStart(1000, '#gwd_wishlist_div', function(){
    try{
        document.querySelector('#gwd_wishlist_div').style.display='none';
        AutoStart(500, '#coupon_box', function(){
            document.querySelector('#coupon_box').style.display='none';
        });
        AutoStart(500, '#bjd_yifenqian_detail', function(){
            document.querySelector('#bjd_yifenqian_detail').style.display='none';
        });
    }catch(e){}
});
AutoStart(5000, '#favor_box', function(){
    var tp = document.querySelector('#favor_box');
    tp.style.display ='none';
});
AutoStart(3000, '#top_coupon_btn', function(){
    var tp = document.querySelector('#top_coupon_btn');
    tp.href = 'javaScript:void(0)';
    tp.onclick = function(){n_item_click(goodID);};
});
if(location.host.indexOf('jd.com') > 0){
     AutoStart(3000, '#gwdang-main', function () {
        var nav = document.querySelector('#gwdang-main');
        try{
        var items = nav.querySelector('#tmall-item-list').children;
        for(i=0;i<items.length;i++){
            item = items[i];
            n_item_load_sc(item);
        }}catch(e){}
        try{
        var items = nav.querySelector('#taobao-item-list').children;
        for(i=0;i<items.length;i++){
            item = items[i];
            n_item_load_sc(item);
        }}catch(e){}
     });

}else if(location.host == 'detail.tmall.com'){
     AutoStart(2000, ".tb-detail-hd, .tb-main-title", function () {
         goodID = getQueryString("id");
     });
     AutoStart(5000, '#gwdang-main', function () {
         tm_618();
         gwd_load_sc();
     });
     AutoStart(5000, "#ald-skuRight > div > div.ald-hd > span", function () {
         AutoStart(1000, '#gwdang-main', function () {
            n_tm_load();
         });
     });
} else if (location.host == 'item.taobao.com') {
     AutoStart(2000, ".tb-detail-hd, .tb-main-title", function () {
         goodID = getQueryString("id");
     });
     AutoStart(5000, "#gwdang-main", function () {
         tb_618();
         n_tb_load();
         gwd_load_sc();
     });
}