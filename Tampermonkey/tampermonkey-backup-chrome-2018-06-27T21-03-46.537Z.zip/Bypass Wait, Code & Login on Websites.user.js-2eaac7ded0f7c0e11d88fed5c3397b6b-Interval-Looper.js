// Interval Looper by Jixun:
// https://gist.github.com/JixunMoe/c77bb3936a68997fce22

var IntervalLoop = function (arrData, looper, delay) {
	if (!(this instanceof IntervalLoop))
		return new IntervalLoop (arrData, looper, delay);
 
	/**
	 * Status
	 * @type Number
	 * 0: ��* �
	 * 1: c(��
	 * 2: ���_
	 */
	this.status = 0;
	this.next = this._next.bind (this);
	this.index = 0;
 
	this.setDelay (delay || 50);
	this.data = (arrData instanceof Array) ? arrData : [];
	this.setLooper (looper);
};
 
IntervalLoop.prototype = {
	_getDelay: function () {
		if (!this.delay)
			return 50;
 
		if (this.delay.apply)
			return this.delay();
 
		return this.delay;
	},
	_next: function () {
		// �9: �L-
		this.status = 1;
		if (this.index < this.data.length) {
			setTimeout (this.looper.bind(this, this.data[this.index]), this.delay);
			this.index ++;
			if (this.onProgress && this.onProgress.apply) {
				try {
					this.onProgress (this.index, this.data.length);
				} catch (e) {
					console.error ('Error while callback to `onProgress`');
					console.error (e);
				}
			}
		} else {
			this.status = 2;
			if (this.onComplete && this.onComplete.apply) {
				try {
					this.onComplete (this.data.length);
				} catch (e) {
					console.error ('Error while callback to `onComplete`');
					console.error (e);
				}
			}
		}
	},
	cleanup: function () {
		if (this.status == 2) {
			// ��(Ǆpn1�
			this.data.splice(0, this.index);
			this.index = 0;
			this.status = 0;
		}
 
		return this;
	},
	add: function () {
		if (arguments.length > 0) {
			// @	�p\:pn�e this.data
			for (var i = 0; i<arguments.length; i++)
				this.data.push (arguments[i]);
 
			// t*��ό����
			if (this.status == 2)
				this.cleanup().next();
		}
 
		// �
		return this;
	},
	setDelay: function (newDelay) {
		if (newDelay) this.delay = parseInt (newDelay);
		return this;
	},
	setLooper: function (fooCallback) {
		if (fooCallback && fooCallback.apply)
			this.looper = fooCallback.bind(this, this.next);
 
		return this;
	},
	loop: function () {
		if (this.status == 0)
			// */�, �4 �
			this.next ();
 
		return this;
	}
};