// ==UserScript==
// @name         闲鱼搜索框+宝贝标题+去二维码
// @namespace    http://tampermonkey.net/
// @version      0.3
// @description  还原右上搜索框, 显示宝贝标题, 清除各种二维码
// @author       cuteribs
// @match        https://2.taobao.com/*
// @match        https://s.2.taobao.com/*
// @match        https://trade.2.taobao.com/*
// @match        http://s.ershou.taobao.com/*
// @grant        none
// @require      http://code.jquery.com/jquery-latest.js
// @icon         https://www.taobao.com/favicon.ico
// ==/UserScript==

(function () {
	// 添加搜索框
	let form = '<div class="idle-search"><form method="get" action="//s.2.taobao.com/list/list.htm" name="search" target="_top"><input class="input-search" id="J_HeaderSearchQuery" name="q" type="text" value="" placeholder="搜闲鱼" /><input type="hidden" name="search_type" value="item" autocomplete="off" /><input type="hidden" name="app" value="shopsearch" autocomplete="off" /><button class="btn-search" type="submit"><i class="iconfont">&#xe602;</i><span class="search-img"></span></button></form></div>';
	$('#J_IdleHeader').append(form);

	// 隐藏首页左下二维码
	var bodyObs = new MutationObserver(list => {
		if (list.length > 0 && list[0].addedNodes.length > 0)
			var $downloadLayer = $(list[0].addedNodes[0]).find('.download-layer');

		if ($downloadLayer.length > 0) {
			$downloadLayer.remove();
		}
	});
	bodyObs.observe(document.body, { childList: true });

	// 显示搜索页的宝贝标题
	var appendTitle = item => {
		var $a = $(item).find('.item-pic a');

		if ($a.index('h2') == -1) {
			$a.prepend(`<h2 style="font-size: 1.2em; color: #333; font-weight: bold; text-decoration: none;">${$a.attr('title')}</h2>`);
		}
	};

	$('#J_ItemListsContainer .ks-waterfall').each((i, item) => appendTitle(item));

	var listObs = new MutationObserver(list => {
		for (let i = 0; i < list.length; i++) {
			if (list[i].addedNodes.length > 0) {
				appendTitle(list[i].addedNodes[0]);
			}
		}
	});
	listObs.observe(document.getElementById('J_ItemListsContainer'), { childList: true });

	// 隐藏搜索页的底部二维码
	$('#popUp-div').remove();

	// 隐藏宝贝详情页的头图二维码
	$('.mau-guide').remove();
})();
