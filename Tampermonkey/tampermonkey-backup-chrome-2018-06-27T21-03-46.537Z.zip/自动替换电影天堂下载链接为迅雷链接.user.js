// ==UserScript==
// @name         自动替换电影天堂下载链接为迅雷链接
// @namespace    undefined
// @version      0.2.2
// @description  去除获取最新迅雷检测，直接迅雷下载
// @author       x2009again
// @match        *://www.dy2018.com/*
// @match        *://www.ygdy8.com/*
// @match        *://www.dygod.net/*
// @match        *://www.dytt8.net/*
// @grant        none
// @run-at            document-end
// ==/UserScript==
var counter = 0;
var linkflag = false;
function myinit() {
  var thunderlink = document.getElementsByTagName('a');
  for (var i = 0; i < thunderlink.length; i++) {
    if (thunderlink[i].getAttribute('thunderpid')) {
      var realthunderlink = '';
      var linkattributes = thunderlink[i].attributes;
      for (var j = 0; j < linkattributes.length; j++)
      {
        if (linkattributes[j].value.indexOf('thunder:/') == 0)
        {
          realthunderlink = linkattributes[j].value;
          linkflag = true;
          break;
        }
      }
      console.log('realthunderlink:' + realthunderlink);
      thunderlink[i].href = realthunderlink;
    }
  }
}
var
t = window.setInterval(function () { //设置一个延时循环，每隔200ms选择一下所需的元素，当所需的元素存在时，开始脚本，同时停止延时循环 
  myinit();
  if (linkflag) {
    window.clearInterval(t);
  } 
  else {
    if (counter < 5) {
      //console.log('waiting');
      counter++;
    } 
    else {
      window.clearInterval(t);
      //console.log('out of time');
    }
  }
}, 200);
