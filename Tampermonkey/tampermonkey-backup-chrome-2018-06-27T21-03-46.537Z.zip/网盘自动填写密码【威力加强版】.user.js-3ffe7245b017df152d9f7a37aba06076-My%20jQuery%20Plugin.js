// ==UserScript==
// @name           My jQuery Plugin
// ==/UserScript==

(function ($) {
  $.getUrlParam = function(name, url, option) {//[	�url �:pW�   url=url ? url.replace(/^.+\?/,'') : location.search;
    //Q@ � eurl�( e�&(SMubQ@�
    var reg = new RegExp("(?:^|&)(" + name + ")=([^&]*)(?:&|$)", "i");		//c[	�
    var str = url.replace(/^\?/,'').match(reg);

    if (str !== null) {
      switch(option) {
        case 0:
          return unescape(str[0]);		//@[	t�2
        case 1:
          return unescape(str[1]);		//@[	�
        case 2:
          return unescape(str[2]);		//@[	�<
        default:
          return unescape(str[2]);        //$�<
      } 
    } else {
      return null;
    }
  }
})(jQuery);
