// ==UserScript==
// @name         yifile网盘跳过等待
// @namespace    http://tampermonkey.net/
// @version      0.3.1
// @description  try to take over the world!
// @author       Yao
// @match        https://www.yifile.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    // downtime=1;
    window.onload = function () {
        $(".stxt").hide();
        $("#bootyz1").show();
        $("#bootyz2").show();
        $("#bootyz3").show();
    };
})();