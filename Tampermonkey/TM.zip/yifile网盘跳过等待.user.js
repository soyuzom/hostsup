// ==UserScript==
// @name         yifile网盘跳过等待
// @namespace    http://tampermonkey.net/
// @version      0.2
// @description  try to take over the world!
// @author       Yao
// @match        https://www.yifile.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    downtime=1;
})();